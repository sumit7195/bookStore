// const { default: mongoose } = require("mongoose");
const mongoose  = require("mongoose");

const booksSchema = new mongoose.Schema({

    Title : {type:"String"},
    Author : {type:"String"},
    Price : {type:"Number"},
    img : [{
           type:"String", required:true
    }]
       
},{
    timestamps:true,
    versionKey:false
})



module.exports = mongoose.model('Books',booksSchema)