const bcryptjs = require("bcryptjs")
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({

  name : {type:String, required: true},
  email : {type:String, requied:true},
  password: {type:String, required: true}
}
,
{
    timestamps : true,
    versionKey : false
}
)


userSchema.pre('save', function(next){
    this.password = bcryptjs.hashSync(this.password, 8)

    next()
})


userSchema.methods.checkPass = function(bodypass){

 
    return bcryptjs.compareSync(bodypass.toString(), this.password)


}



module.exports = mongoose.model('user', userSchema)