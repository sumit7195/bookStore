require("dotenv").config();
const mongoose = require("mongoose");

module.exports = () => {
  mongoose.connect(
    `mongodb+srv://sumit:${process.env.PASS}@cluster0.nbecc.mongodb.net/Books_api?retryWrites=true&w=majority`
  );
};

// mongodb+srv://sumit:Raja123@cluster0.nbecc.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
