const app = require("./index");

const connect = require("./db/db")


const start = () => {
  return app.listen(3002, async () => {
    
   await connect()
    console.log("server is listening on port 3002");
  });
};

module.exports = start;
