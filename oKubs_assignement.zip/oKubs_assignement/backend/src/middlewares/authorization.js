require("dotenv").config();
const jwt = require("jsonwebtoken")


const authorization = (req, res, next) => {
  const token = req.cookies.token;
//   console.log(token)
  if (!token) {
    return res.sendStatus(403);
  }
  try {
    const data = jwt.verify(token, "dfafgkggdssggsjgdgeglagagaggagaga");
    // Almost done
    // req.userId = data.id;
    req.name = data.name
    
    
    // console.log(data)

    return next()
    
    
  } catch {
    return res.sendStatus(403);
  }
 
};


module.exports = authorization