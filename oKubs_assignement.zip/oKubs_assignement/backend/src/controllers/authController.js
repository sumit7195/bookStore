const { body, validationResult } = require("express-validator");
require("dotenv").config();

const jwt = require("jsonwebtoken");
const User = require("../models/userSchema");

const tokenGenerator = (user) => {
  return jwt.sign({ user }, process.env.JWT_SECRET);
};

// register user

const registerController = async (req, res) => {
  let errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(500).send(errors.array());
  }
  
  
  // if email is already present

  try {
    let user = await User.findOne({ email: req.body.email });

    if (user) {
      return res.status(500).send("Email is already present");
    }

    // if email is not present

    user = await User.create(req.body);
    //generate a token and return to frontend

    // return res.status(201).send({ user, token });

    //  process.env.token = "Bearer " + "" + token;
    generateToken(user, 201, res);
    res.redirect("/")
  } catch (e) {
    console.log(e);
    
  }
};

// login controller

const loginController = async (req, res) => {
  let errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(500).send(errors.array());
  }

  try {
    // if email is not present , throw a error
    // console.log(req.body)
    let user = await User.findOne({ email: req.body.email });
    if (!user) {
      return res.status(500).send("Invalid email or password");
    }

    // if password is not matched

    if (user.checkPass(req.body.password)) {
      // genreate  a token and return to frontend
       generateToken(user, 201, res);

      //decoding a token
        

    //   process.env.token = "Bearer " + "" + token;

    //  console.log(user)

     
    } else {
      return res.status(500).send("Invalid email or password");
    }
  } catch (e) {
    console.log(e);
    res.status(500).send(e);
  }
};

const generateToken = async (user, statusCode, res) => {
  let token = tokenGenerator(user);
  const options = {
    httpOnly: true,
    expires: new Date(Date.now() + process.env.EXPIRES_TOKEN),
  };
  
  
  res.status(statusCode).cookie("token",token, options).redirect("/")



};

module.exports = { registerController, loginController };
