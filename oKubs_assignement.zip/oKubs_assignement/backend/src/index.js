const express = require("express");
const app = express();
module.exports = app;
app.use(express.json());
// const upload = require("./routes/upload");
// const Grid = require("gridfs-stream");
// const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
// const userController =require("./controllers/user.controller")
const authenticate = require("./middlewares/authenticate")
const authorization = require("./middlewares/authorization")

// const loginController = require("./controllers/authController")


const { body, validationResult } = require("express-validator");


const {registerController, loginController} = require("./controllers/authController")

const Books = require("./models/books.modle");


//middlewares
app.use(bodyParser.json());
app.use(cookieParser())
app.use(bodyParser.urlencoded({ extended: false }));




// app.get("/",authenticate, (req, res) => {
//   res.send("hello");
// });

app.post("", async (req, res) => {
  try {
    const books = await Books.create(req.body);
    res.status(201).send(books);
  } catch (error) {
    res.status(500).send(error);
  }
});

app.get("/books", async (req, res) => {
  try {
    const books = await Books.find().populate();
    res.status(201).send(books);
  } catch (error) {
    res.status(500).send(error);
  }
});




app.post(
  "/register",

  body("name").notEmpty().withMessage("Name cannot be empty"),

  body("email").isEmail().withMessage("not a valid email"),

  body("password").notEmpty().withMessage("Password cannot be empty"),

  registerController
);



app.post(
  "/Login",
  body("email").isEmail().withMessage("Not  a valid Email!"),
  body("password").notEmpty().withMessage("Password cannot be empty!"),
  loginController
);




app.use("/login", loginController,authorization)


















app.get("/books/:bookid", authorization, async (req, res) => {
  try {
    let id = req.params;

    const books = await Books.findById(id.bookid).exec();

    res.send(books);
  } catch (error) {
    res.send(error);
  }
});

const start = require("./server");
// const authorization = require("./middlewares/authorization");


start();
