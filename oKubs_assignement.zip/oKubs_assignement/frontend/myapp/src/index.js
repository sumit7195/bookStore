import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import store from "./redux/store";

import { Provider } from "react-redux";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Cart from "./components/Cart";
import Singup from "./components/SIngup";
import Login from "./components/Login"


ReactDOM.render(
  
  <Provider store={store}>

      <Router>
        <Routes>
          <Route path="/" element={<App />}></Route>
          <Route path="/cart" element={<Cart />} />
          <Route path="/signUp" element={<Singup />} />
          <Route path="/loginUp" element={<Login />} />
        </Routes>
      </Router>

  </Provider>,
  
  document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();
