const intialState = {
  loading: false,
  list: [],
  error: " ",
};

const reducer = (state = intialState, action) => {
  switch (action.type) {
    case "FETCH_DATA_REQUEST":
      return {
        ...state,
        loading: true,
      };

    case "FETCH_DATA":
      return {
        ...state,
        loading: false,
        list: action.payload,
      };

    case "FETCH_DATA_FAILURE":
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    
    
    case "CART_DETAIL_DATA":
      return{
        ...state,
        loading: false,
        list : action.payload
      }
    

    default:
      return state;
  }
};


export default reducer;