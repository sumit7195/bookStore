import axios from "axios";

export const Fetch_data = (data) => {
 console.log(data)  
 
  return {
    type: "FETCH_DATA",
    payload: data,
    error: "",
  };
};

export const fetch_Data_Request = () => {
  return {
    type: "FETCH_DATA_REQUEST",
  };
};

export const fetch_data_failure = (error) => {
  return {
    type: "FETCH_DATA_FAILURE",
    payload: error,
  };
};

export function getData() {
  return function (dispatch) {
    dispatch(fetch_Data_Request());

    return axios
      .get("/books")
      .then(({ data }) => {
        dispatch(Fetch_data(data));
      })
      .catch((error) => {
        const errorMsg = error.message;
        dispatch(fetch_data_failure(errorMsg));
      });
  };
}

export function CartDetail(id) {
  console.log(id);

  return function (dispatch) {
    dispatch(fetch_Data_Request());

    return axios
      .get(`/books/${id}`)
      .then(({ data }) => {
        dispatch(cart_detail_data(data));
      })
      .catch((error) => {
        const errorMsg = error.msg;
        dispatch(fetch_data_failure(errorMsg));
      });
  };
}

export const cart_detail_data = (data) => {
  return {
    type: "CART_DETAIL_DATA",
    payload: [data],
    error: "",
  };
};
