import React from "react";

import { useEffect } from "react";

import { connect } from "react-redux";
import { getData } from "../redux/actions";
import { useSelector } from "react-redux";

import "../css/books.css"
import { Outlet, useNavigate } from "react-router-dom";


const Books = (props) => {
  useEffect(() => {
    props.getData();
  }, []);

  const list = useSelector((state) => state.list);

  const loading = useSelector((state) => state.loading);
 
   const navigate = useNavigate();


  return loading ? (
    <h1>...loading</h1>
  ) : (
    <div className="mainDiv">
      {list.map(({ _id, Title, Author, Price, img }) => {
        const imgs = img[0];
        // console.log(id)
        return (
          <div key={_id} className="innerdiv">
            <div>
              <img src={`${imgs}`} alt="" />
            </div>
            <div>
              <h1>{Title}</h1>
              <h3>{Author}</h3>
              <h3>{Price} ₹ </h3>
            </div>
            <div className="btn">
              {" "}
              <button onClick={()=> navigate("/cart", {state: _id })}>ADD TO CART</button>
            </div>
          </div>
        );
      })}
      <Outlet/>
    </div>
  );
};

export default connect(null, { getData })(Books);
