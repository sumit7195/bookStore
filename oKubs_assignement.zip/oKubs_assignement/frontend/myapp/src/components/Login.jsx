import React from 'react';
import { useState } from 'react';
import axios from 'axios';
// import { useCookies } from 'react-cookie';
// import jwt from "jwt-decode"
import { useNavigate } from 'react-router-dom';

const Login = () => {

// const [cookies,setCookie] = useCookies(['token'])

// console.log(cookies)
const navigate = useNavigate();

  const [data, setData] = useState({


    email:"",
    password:""
})

let name , value;

const handleInputs = (e) => {
  //   console.log(e)

  name = e.target.name;
  value = e.target.value;

  setData({ ...data, [name]: value });
};


const postData = async (e) => {
  e.preventDefault();
  const {  email, password } = data;

  axios({
    method: "POST",
    url: "/Login",
    data: {
      
      email,
      password,
    },
  })
    .then((res) => {

    console.log(res)
          


    })
    .catch((error) => {
      console.log(error);
    });
};




    return (
      <div>
        <form method="POST" action="/Login">
          <input
            type="email"
            placeholder="Enter the email"
            name="email"
            value={data.email}
            onChange={handleInputs}
          />
          <input
            type="password"
            placeholder="enter the password"
            name="password"
            value={data.password}
            onChange={handleInputs}
          />

          <input type="submit" onClick={()=>postData} />
        </form>
      </div>
    );
}

export default Login;
