import React from "react";
import { useState } from "react";
import axios from "axios";
import {useNavigate} from "react-router-dom"

const Singup = () => {

// const navigate = useNavigate()


  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
  });

  let name, value;

  const handleInputs = (e) => {
    //   console.log(e)

    name = e.target.name;
    value = e.target.value;

    setUser({ ...user, [name]: value });
  };

  

  const postData =  async(e) => {
    e.preventDefault()
   const {name, email, password} = user;
    
   axios({
     method: "POST",
     url: "/register",
     data:{
         name, email , password
     }
   }).then((res)=> console.log(res))
   .catch((error)=>{
       console.log(error)
   }
   ) 

  };

  return (
    <div>
      <form  method="POST" action="/register">
        <input
          type="text"
          name="name"
          placeholder="Enter Name"
          value={user.name}
          onChange={handleInputs}
        />
        <input
          type="email"
          name="email"
          placeholder="Enter email"
          value={user.email}
          onChange={handleInputs}
        />
        <input
          type="password"
          name="password"
          placeholder="enter your password"
          value={user.password}
          onChange={handleInputs}
        />

        <input type="submit"      onClick={()=> postData}        />
      </form>
    </div>
  );
};

export default Singup;
