import React from "react";
import { Link } from "react-router-dom";
import "../css/navbar.css"
const Navbar = () => {
  return (
    <ul className="navbar">
      <li>Home</li>
      <li>Cart</li>
      <li>
        <Link to="/signUp">SignUp</Link>
      </li>
      <li> <Link to="/loginUp">login</Link></li>
    </ul>
  );
};

export default Navbar;
