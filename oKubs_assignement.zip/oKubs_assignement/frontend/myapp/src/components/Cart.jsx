import React from "react";
import { useLocation } from "react-router-dom";
import { connect } from "react-redux";
import { CartDetail } from "../redux/actions";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import "../css/cart.css"
const Cart = (props) => {
  const location = useLocation();
  const id = location.state;

  const loading = useSelector((state) => state.loading);
  const list = useSelector((state) => state.list);

  useEffect(() => {
    props.CartDetail(id);
  }, []);

  return loading ? (
    <h1>...loading</h1>
  ) : (
    <div className="maindiv">
      {list.map(({ _id, Title, Author, Price, img }) => {
        let imgs = img[0];

        return (
          <div key={_id} className="inner">
            <div>
              <img src={`${imgs}`} alt="" />
            </div>
            <h1>{Title}</h1>
            <h3>{Author}</h3>
            <h3>{Price}</h3>
            <div className="btn"><button>BUY</button></div>
          </div>
        );
      })}
    </div>
  );
};

export default connect(null, { CartDetail })(Cart);
